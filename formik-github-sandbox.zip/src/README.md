# Formik Basic Example

This example demonstrates how to use Formik in its most basic way.

[![Edit formik-example-basic](https://codesandbox.io/static/img/play-codesandbox.svg)](https://codesandbox.io/s/github/jaredpalmer/formik/tree/master/examples/basic?fontsize=14&hidenavigation=1&theme=dark)
